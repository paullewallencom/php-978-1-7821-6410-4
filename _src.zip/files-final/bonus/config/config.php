<?php

// App configuration
$dbParams = [
    'driver' => 'pdo_sqlite',
    'path' => __DIR__.'/../data/blog.db'
];

// Dev mode?
$dev = true;
